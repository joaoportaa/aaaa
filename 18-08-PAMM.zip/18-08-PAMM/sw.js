self.addEventListener("install", (event) => {
    console.log ("sw instalido.");
caches.open("triolingo").then((cache) =>{
    console.log ("cacheAberto")
    cache.add("index.html");
})
})